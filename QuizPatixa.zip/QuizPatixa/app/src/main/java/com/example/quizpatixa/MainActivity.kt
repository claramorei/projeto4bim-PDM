package com.example.quizpatixa

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.random.Random

/* ============================================================
 *  🎀 QUIZ DA PATIXA TELÓ 🎀
 *  Jetpack Compose + Material 3 (template "Empty Activity")
 *  Conceitos: RadioButton, Column, Button, data class, List,
 *  rememberSaveable + desafio extra (categorias, tempo e ranking)
 * ============================================================ */

// ---------- Cores kawaii ----------
private val Pink = Color(0xFFFF6FA5)
private val PinkDark = Color(0xFFE0457F)
private val PinkLight = Color(0xFFFFD6E7)
private val PinkBg1 = Color(0xFFFFF0F6)
private val PinkBg2 = Color(0xFFFFE3F0)
private val Lavender = Color(0xFFE9D8FF)
private val Mint = Color(0xFFCFF5E3)
private val Rose = Color(0xFFFFCDD2)
private val Cocoa = Color(0xFF6B2D4A)

private const val TIME_PER_QUESTION = 20 // segundos por pergunta

// ---------- Modelo de dados ----------
data class Question(
    val category: String,
    val text: String,
    val options: List<String>, // sempre 5 alternativas
    val correctIndex: Int
)

data class RankEntry(
    val name: String,
    val score: Int,
    val correct: Int,
    val total: Int
)

private fun q(category: String, text: String, correct: String, vararg wrong: String): Question =
    Question(category, text, listOf(correct) + wrong.toList(), 0)

private fun Question.shuffled(rnd: Random): Question {
    val right = options[correctIndex]
    val mixed = options.shuffled(rnd)
    return copy(options = mixed, correctIndex = mixed.indexOf(right))
}

// ---------- Banco de perguntas (25) ----------
private val questionBank: List<Question> = listOf(
    // Quem é ela 👑
    q("Quem é ela 👑", "Qual é o nome artístico da influenciadora do nosso quiz?",
        "Patixa Teló", "Patrícia Teló", "Patixa Maia", "Patty Amazonas", "Patixa Joelma"),
    q("Quem é ela 👑", "Qual é o apelido mais famoso da Patixa?",
        "Rainha do Amazonas", "Rainha do Pará", "Princesa de Manaus", "Imperatriz do Norte", "Rainha do Carnaval"),
    q("Quem é ela 👑", "Em que cidade a Patixa nasceu?",
        "Juruti (PA)", "Manaus (AM)", "Belém (PA)", "Parintins (AM)", "Santarém (PA)"),
    q("Quem é ela 👑", "Em qual cidade a Patixa foi criada?",
        "Manaus", "Belém", "Macapá", "Porto Velho", "Rio Branco"),
    q("Quem é ela 👑", "Em qual cidade a Patixa mora atualmente?",
        "Belém", "Manaus", "São Paulo", "Rio de Janeiro", "Fortaleza"),
    q("Quem é ela 👑", "Segundo as reportagens, em que faixa de idade a Patixa está?",
        "Na casa dos 40 anos", "Na casa dos 20 anos", "Na casa dos 30 anos", "Na casa dos 50 anos", "Na casa dos 60 anos"),
    q("Quem é ela 👑", "Além de Rainha do Amazonas, como ela também é chamada nas redes?",
        "Diva", "Madrinha", "Chacrete", "Musa do verão", "Dama da noite"),
    q("Quem é ela 👑", "Quase quantos seguidores a Patixa reúne nas redes sociais?",
        "Mais de 1 milhão", "Cerca de 5 mil", "Cerca de 20 mil", "Cerca de 100 mil", "Cerca de 50 mil"),

    // TV e Reality 📺
    q("TV e Reality 📺", "Qual reality show deu projeção nacional à Patixa?",
        "Rancho do Maia", "Big Brother Brasil", "A Fazenda", "De Férias com o Ex", "Casa do Patrão"),
    q("TV e Reality 📺", "Quem comanda o Rancho do Maia?",
        "Carlinhos Maia", "Whindersson Nunes", "Luciano Huck", "Tadeu Schmidt", "Fernando Braga"),
    q("TV e Reality 📺", "Em que ano aconteceu o Rancho do Maia que a Patixa participou?",
        "2024", "2019", "2020", "2022", "2026"),
    q("TV e Reality 📺", "Em qual reality musical da TV Globo a Patixa foi convidada especial da plateia?",
        "Estrela da Casa", "The Voice Brasil", "Domingão", "Big Brother Brasil", "Dança dos Famosos"),
    q("TV e Reality 📺", "Qual ator a Patixa conheceu nos bastidores do Estrela da Casa?",
        "Cauã Reymond", "Chay Suede", "Rodrigo Santoro", "Lázaro Ramos", "Selton Mello"),
    q("TV e Reality 📺", "Em qual ação ligada ao BBB 26 a Patixa marcou presença?",
        "Espiadinha BBB", "Festa do Líder", "Prova do Anjo", "Sincerão", "Big Fone"),

    // Memes e Frases 💬
    q("Memes e Frases 💬", "Qual frase marcou a resposta da Patixa a uma fã que disse que não achava que ia vê-la pessoalmente?",
        "\"Tá vendo agora\"", "\"Eu também te amo\"", "\"Tira foto logo\"", "\"Que saudade de você\"", "\"Chega mais perto\""),
    q("Memes e Frases 💬", "A \"bateria social\" da Patixa é famosa por estar como?",
        "Zero", "Cheia", "Na metade", "Quase carregando", "Infinita"),
    q("Memes e Frases 💬", "Um dos maiores memes dela é o vídeo dizendo que vai embora de qual cidade?",
        "Manaus", "Belém", "Parintins", "Juruti", "Santarém"),
    q("Memes e Frases 💬", "O que a Patixa disse, em um vídeo, que queria fazer na Alepa, em Belém?",
        "Falar com deputados", "Cantar no plenário", "Conhecer o governador", "Pedir um emprego", "Fazer uma live"),

    // Lugares e Festas 🗺️
    q("Lugares e Festas 🗺️", "A Patixa é embaixadora de qual boi do Festival de Parintins?",
        "Caprichoso", "Garantido", "Corre Campo", "Boi Bumbá Estrela", "Boi da Cara Preta"),
    q("Lugares e Festas 🗺️", "Em qual estado acontece o Festival de Parintins?",
        "Amazonas", "Pará", "Acre", "Amapá", "Roraima"),
    q("Lugares e Festas 🗺️", "Em qual cidade ela foi ovacionada por estudantes em um congresso?",
        "Campo Grande (MS)", "Goiânia (GO)", "Curitiba (PR)", "Recife (PE)", "Brasília (DF)"),
    q("Lugares e Festas 🗺️", "Em qual cidade a Patixa encontrou a cantora Joelma em um vídeo que bombou?",
        "Belém", "Manaus", "Fortaleza", "Salvador", "Goiânia"),

    // Curiosidades ✨
    q("Curiosidades ✨", "Qual influenciador acompanha a Patixa profissionalmente e é conhecido como Fefa?",
        "Fernando Braga", "Carlinhos Maia", "Allan Barros", "Joel Marques", "Rafael Santos"),
    q("Curiosidades ✨", "Qual cantora a Patixa disse que \"se adora\" em um encontro em Belém?",
        "Joelma", "Ivete Sangalo", "Gaby Amarantos", "Wanessa Camargo", "Luísa Sonza"),
    q("Curiosidades ✨", "O que a Patixa celebrou nas redes em outubro de 2025?",
        "Novo sorriso com implantes dentários", "Um carro novo", "Um novo corte de cabelo", "Uma viagem à Europa", "Um disco de estreia")
)

// ---------- Ranking local (SharedPreferences) ----------
private object RankingStore {
    private const val PREFS = "ranking_patixa"
    private const val KEY = "entries"

    fun load(context: Context): List<RankEntry> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "") ?: ""
        return raw.split("\n").mapNotNull { line ->
            val p = line.split("|")
            if (p.size != 4) return@mapNotNull null
            val score = p[1].toIntOrNull() ?: return@mapNotNull null
            val correct = p[2].toIntOrNull() ?: return@mapNotNull null
            val total = p[3].toIntOrNull() ?: return@mapNotNull null
            RankEntry(p[0], score, correct, total)
        }
    }

    fun save(context: Context, entry: RankEntry) {
        val clean = entry.copy(name = entry.name.replace("|", " ").replace("\n", " ").trim())
        val top = (load(context) + clean)
            .sortedWith(compareByDescending<RankEntry> { it.score }.thenByDescending { it.correct })
            .take(10)
        val raw = top.joinToString("\n") { "${it.name}|${it.score}|${it.correct}|${it.total}" }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, raw).apply()
    }
}

private fun buildQuiz(count: Int, seed: Long): List<Question> {
    val rnd = Random(seed)
    return questionBank.shuffled(rnd).take(count).map { it.shuffled(rnd) }
}

// ---------- Activity ----------
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            PatixaTheme {
                PatixaQuizApp()
            }
        }
    }
}

@Composable
fun PatixaTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Pink,
            onPrimary = Color.White,
            secondary = Lavender,
            onSecondary = Cocoa,
            background = PinkBg1,
            surface = Color.White,
            onSurface = Cocoa,
            onBackground = Cocoa
        ),
        content = content
    )
}

// ---------- App (estado + navegação) ----------
@Composable
fun PatixaQuizApp() {
    val context = LocalContext.current

    // 0 = menu, 1 = quiz, 2 = resultado, 3 = ranking
    var stage by rememberSaveable { mutableIntStateOf(0) }
    var playerName by rememberSaveable { mutableStateOf("") }
    var totalQuestions by rememberSaveable { mutableIntStateOf(10) }
    var seed by rememberSaveable { mutableLongStateOf(0L) }

    var currentIndex by rememberSaveable { mutableIntStateOf(0) }
    var selected by rememberSaveable { mutableIntStateOf(-1) }
    var locked by rememberSaveable { mutableStateOf(false) }
    var correctCount by rememberSaveable { mutableIntStateOf(0) }
    var wrongCount by rememberSaveable { mutableIntStateOf(0) }
    var score by rememberSaveable { mutableIntStateOf(0) }
    var timeLeft by rememberSaveable { mutableIntStateOf(TIME_PER_QUESTION) }

    val questions = remember(seed, totalQuestions) { buildQuiz(totalQuestions, seed) }

    fun startQuiz() {
        seed = System.currentTimeMillis()
        currentIndex = 0
        selected = -1
        locked = false
        correctCount = 0
        wrongCount = 0
        score = 0
        timeLeft = TIME_PER_QUESTION
        stage = 1
    }

    fun confirmAnswer() {
        if (locked || selected == -1) return // não permite responder duas vezes
        locked = true
        if (selected == questions[currentIndex].correctIndex) {
            correctCount++
            score += 10 + timeLeft / 2 // 10 pontos + bônus de velocidade
        } else {
            wrongCount++
        }
    }

    fun timeUp() {
        if (locked) return
        locked = true
        wrongCount++
    }

    fun nextQuestion() {
        if (currentIndex + 1 >= questions.size) {
            RankingStore.save(
                context,
                RankEntry(playerName.ifBlank { "Anônimo" }, score, correctCount, questions.size)
            )
            stage = 2
        } else {
            currentIndex++
            selected = -1
            locked = false
            timeLeft = TIME_PER_QUESTION
        }
    }

    // Cronômetro por pergunta
    LaunchedEffect(stage, currentIndex, locked) {
        if (stage == 1 && !locked) {
            while (timeLeft > 0) {
                delay(1000)
                timeLeft--
            }
            if (!locked) timeUp()
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(PinkBg1, PinkBg2, Lavender.copy(alpha = 0.6f))))
            .systemBarsPadding()
    ) {
        when (stage) {
            0 -> MenuScreen(
                playerName = playerName,
                onNameChange = { if (it.length <= 16) playerName = it },
                totalQuestions = totalQuestions,
                onTotalChange = { totalQuestions = it },
                onStart = { startQuiz() },
                onRanking = { stage = 3 }
            )

            1 -> QuizScreen(
                question = questions[currentIndex],
                index = currentIndex,
                total = questions.size,
                selected = selected,
                locked = locked,
                timeLeft = timeLeft,
                score = score,
                onSelect = { if (!locked) selected = it },
                onConfirm = { confirmAnswer() },
                onNext = { nextQuestion() }
            )

            2 -> ResultScreen(
                name = playerName.ifBlank { "Anônimo" },
                total = questions.size,
                correct = correctCount,
                wrong = wrongCount,
                score = score,
                onRestart = { startQuiz() },
                onMenu = { stage = 0 },
                onRanking = { stage = 3 }
            )

            else -> RankingScreen(onBack = { stage = 0 })
        }
    }
}

// ---------- Componentes ----------
@Composable
private fun KawaiiCard(
    modifier: Modifier = Modifier,
    color: Color = Color.White,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(containerColor = color),
        border = BorderStroke(2.dp, PinkLight),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column(modifier = Modifier.padding(20.dp), content = content)
    }
}

@Composable
private fun BigButton(text: String, enabled: Boolean = true, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        enabled = enabled,
        modifier = Modifier
            .fillMaxWidth()
            .height(54.dp),
        shape = RoundedCornerShape(50),
        colors = ButtonDefaults.buttonColors(
            containerColor = Pink,
            disabledContainerColor = PinkLight,
            disabledContentColor = Color.White
        )
    ) {
        Text(text, fontSize = 17.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun SoftButton(text: String, onClick: () -> Unit) {
    OutlinedButton(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .height(54.dp),
        shape = RoundedCornerShape(50),
        border = BorderStroke(2.dp, Pink),
        colors = ButtonDefaults.outlinedButtonColors(contentColor = PinkDark)
    ) {
        Text(text, fontSize = 16.sp, fontWeight = FontWeight.Bold)
    }
}

// ---------- Tela: Menu ----------
@Composable
private fun MenuScreen(
    playerName: String,
    onNameChange: (String) -> Unit,
    totalQuestions: Int,
    onTotalChange: (Int) -> Unit,
    onStart: () -> Unit,
    onRanking: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(8.dp))
        Text("🎀👑🎀", fontSize = 40.sp)
        Text(
            "Quiz da Patixa Teló",
            fontSize = 32.sp,
            fontWeight = FontWeight.ExtraBold,
            color = PinkDark,
            textAlign = TextAlign.Center
        )
        Text(
            "Será que você é fã de verdade? ✨",
            fontSize = 16.sp,
            color = Cocoa,
            textAlign = TextAlign.Center
        )

        KawaiiCard {
            Text("Seu apelido 💖", fontWeight = FontWeight.Bold, color = PinkDark)
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = playerName,
                onValueChange = onNameChange,
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                placeholder = { Text("Digite seu nome para o ranking") },
                shape = RoundedCornerShape(20.dp)
            )
        }

        KawaiiCard {
            Text("Quantas perguntas? 🌸", fontWeight = FontWeight.Bold, color = PinkDark)
            Spacer(Modifier.height(12.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf(10, 15, 20).forEach { n ->
                    val on = n == totalQuestions
                    Button(
                        onClick = { onTotalChange(n) },
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp),
                        shape = RoundedCornerShape(50),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (on) Pink else PinkLight,
                            contentColor = if (on) Color.White else PinkDark
                        )
                    ) {
                        Text("$n", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
            Text(
                "⏰ ${TIME_PER_QUESTION}s por pergunta • quanto mais rápido, mais pontos!",
                fontSize = 13.sp
            )
        }

        BigButton("Começar 💕", onClick = onStart)
        SoftButton("🏆 Ranking", onClick = onRanking)
        Spacer(Modifier.height(8.dp))
    }
}

// ---------- Tela: Quiz ----------
@Composable
private fun QuizScreen(
    question: Question,
    index: Int,
    total: Int,
    selected: Int,
    locked: Boolean,
    timeLeft: Int,
    score: Int,
    onSelect: (Int) -> Unit,
    onConfirm: () -> Unit,
    onNext: () -> Unit
) {
    val answered = index + if (locked) 1 else 0
    val timedOut = locked && (selected == -1 || timeLeft == 0) && selected != question.correctIndex

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Progresso
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Pergunta ${index + 1} de $total", fontWeight = FontWeight.Bold, color = PinkDark)
            Text("⭐ $score pts", fontWeight = FontWeight.Bold, color = PinkDark)
        }
        LinearProgressIndicator(
            progress = { answered.toFloat() / total },
            modifier = Modifier
                .fillMaxWidth()
                .height(12.dp),
            color = Pink,
            trackColor = PinkLight,
            strokeCap = androidx.compose.ui.graphics.StrokeCap.Round
        )

        // Tempo
        val timerColor = if (timeLeft <= 5) Color(0xFFD32F2F) else PinkDark
        Text(
            "⏰ ${timeLeft}s",
            modifier = Modifier.align(Alignment.End),
            fontWeight = FontWeight.ExtraBold,
            fontSize = 18.sp,
            color = timerColor
        )

        // Pergunta
        KawaiiCard {
            Surface(shape = RoundedCornerShape(50), color = Lavender) {
                Text(
                    question.category,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(Modifier.height(12.dp))
            Text(question.text, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Cocoa)
        }

        // Alternativas (RadioButton)
        question.options.forEachIndexed { i, option ->
            val bg = when {
                locked && i == question.correctIndex -> Mint
                locked && i == selected -> Rose
                i == selected -> PinkLight
                else -> Color.White
            }
            Surface(
                shape = RoundedCornerShape(22.dp),
                color = bg,
                border = BorderStroke(2.dp, if (i == selected) Pink else PinkLight),
                modifier = Modifier
                    .fillMaxWidth()
                    .selectable(
                        selected = i == selected,
                        enabled = !locked,
                        role = Role.RadioButton,
                        onClick = { onSelect(i) }
                    )
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(
                        selected = i == selected,
                        onClick = null,
                        enabled = !locked,
                        colors = RadioButtonDefaults.colors(selectedColor = PinkDark, unselectedColor = Pink)
                    )
                    Spacer(Modifier.width(10.dp))
                    Text(option, fontSize = 16.sp, modifier = Modifier.weight(1f))
                    if (locked && i == question.correctIndex) Text("✅")
                    if (locked && i == selected && i != question.correctIndex) Text("❌")
                }
            }
        }

        // Feedback
        if (locked) {
            val isRight = selected == question.correctIndex
            Text(
                when {
                    isRight -> "Arrasou! Acertou! 🎉"
                    timedOut && selected == -1 -> "O tempo acabou! ⏰💔"
                    else -> "Ops, não foi dessa vez! 💔"
                },
                modifier = Modifier.fillMaxWidth(),
                textAlign = TextAlign.Center,
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp,
                color = if (isRight) Color(0xFF2E7D32) else Color(0xFFC62828)
            )
        }

        // Botões
        if (!locked) {
            BigButton("Confirmar resposta ✨", enabled = selected != -1, onClick = onConfirm)
        } else {
            BigButton(if (index + 1 >= total) "Ver resultado 🏆" else "Próxima 💕", onClick = onNext)
        }
        Spacer(Modifier.height(8.dp))
    }
}

// ---------- Tela: Resultado ----------
@Composable
private fun ResultScreen(
    name: String,
    total: Int,
    correct: Int,
    wrong: Int,
    score: Int,
    onRestart: () -> Unit,
    onMenu: () -> Unit,
    onRanking: () -> Unit
) {
    val percent = if (total == 0) 0 else correct * 100 / total
    val (emoji, title) = when {
        percent == 100 -> "👑" to "Fã número 1 da Patixa!"
        percent >= 70 -> "💖" to "Você é muito fã!"
        percent >= 40 -> "🌸" to "Tá quase lá!"
        else -> "🥺" to "Bora maratonar a Patixa!"
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(12.dp))
        Text(emoji, fontSize = 64.sp)
        Text(
            title,
            fontSize = 28.sp,
            fontWeight = FontWeight.ExtraBold,
            color = PinkDark,
            textAlign = TextAlign.Center
        )
        Text("Parabéns, $name! 🎀", fontSize = 16.sp)

        KawaiiCard {
            ResultRow("✅ Acertos", "$correct")
            ResultRow("❌ Erros", "$wrong")
            ResultRow("📋 Total de perguntas", "$total")
            ResultRow("📊 Aproveitamento", "$percent%")
            ResultRow("⭐ Pontuação final", "$score pts")
        }

        BigButton("Jogar de novo 💕", onClick = onRestart)
        SoftButton("🏆 Ranking", onClick = onRanking)
        SoftButton("🏠 Menu", onClick = onMenu)
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun ResultRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, fontSize = 17.sp)
        Text(value, fontSize = 17.sp, fontWeight = FontWeight.ExtraBold, color = PinkDark)
    }
}

// ---------- Tela: Ranking ----------
@Composable
private fun RankingScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val entries = remember { RankingStore.load(context) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("🏆 Ranking das Fãs 🏆", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, color = PinkDark)

        KawaiiCard {
            if (entries.isEmpty()) {
                Text("Ainda não tem ninguém aqui... seja a primeira fã! 🌸", textAlign = TextAlign.Center)
            } else {
                entries.forEachIndexed { i, e ->
                    val medal = when (i) {
                        0 -> "🥇"
                        1 -> "🥈"
                        2 -> "🥉"
                        else -> "${i + 1}º"
                    }
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(medal, fontSize = 22.sp, modifier = Modifier.width(44.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(e.name, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                            Text("${e.correct}/${e.total} acertos", fontSize = 13.sp)
                        }
                        Text("${e.score} pts", fontWeight = FontWeight.ExtraBold, color = PinkDark)
                    }
                }
            }
        }

        BigButton("Voltar 🏠", onClick = onBack)
    }
}
